/*
 * RCcar_RunningMode.c
 *
 *  Created on: 2019. 10. 15.
 *      Author: n9646
 */


#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <pigpio.h>
#include <pthread.h>

#include "readPWM.h"
#include "pca9685.h"
#include "sonicsensor_buzzer.h"

#define	weighting 		0.8 	//0 ~ 1
#define 	MAX_PWM 		4096
#define 	LIGHT 			10 //BCM10// wiringpi 12
#define 	YLIGHT			27 //BCM27

int checkthread = 0;
int saveTHRpw = 1500;
int saveSTRpw = 1500;
int calcTicks(float impulseMs, int hertz);
int THRcalibration(int pw, float step);
int STRcalibration(int pw);

int main (void)
{
	INFO* STRinfo = malloc(sizeof(INFO));
	INFO* THRinfo = malloc(sizeof(INFO));
	//라이브러리 초기화, 성공시 버전반환
	if (gpioInitialise() < 0)
	{   printf(" pigpio initialisation failed.\n");
	    return 0;
	}

	//핀모드 설정
	gpioSetMode(THRpin, PI_INPUT);
	gpioSetMode(STRpin, PI_INPUT);
	gpioSetMode(BUZZER, PI_OUTPUT);
	gpioSetMode(SONICTRIG, PI_OUTPUT);
	gpioSetMode(SONICECHO, PI_INPUT);

	gpioSetISRFuncEx(STRpin, EITHER_EDGE, 1, Callback, STRinfo);
	gpioSetISRFuncEx(THRpin, EITHER_EDGE, 1, Callback, THRinfo);

	pthread_t* p1 = gpioStartThread(Warningbuzzer, NULL);
	printf("thread1 start.. (%d)\n", p1);

	while(1)
	{
		int* handle = pca9685setup(ADDRESS, 50);
		if (handle < 0)
				printf("Error: i2cOpen\n");
		time_sleep(0.005);

		getpulse_width(STRinfo);
		getpulse_width(THRinfo);
		pca9685PWMReset(handle);
		THRinfo->pw = THRcalibration(THRinfo->pw, 4);
		STRinfo->pw = STRcalibration(STRinfo->pw);

		if(checkthread == 1)
		{	clock_t t1, t2;
			int count = 0;

			pca9685PWMReset(handle);
			PWMWrite(handle, 1, calcTicks(1.6, HERTZ));
			time_sleep(0.5);
			PWMWrite(handle, 1, calcTicks(1.5, HERTZ));
			i2cClose(handle);
			printf("\n-----------------\n      stop~!! \n-----------------\n");
			gpioSetMode(LIGHT, PI_OUTPUT);
			gpioWrite(LIGHT, 1);
			time_sleep(3);
			printf("\n-----------------\n      move slow \n-----------------\n");
			gpioWrite(LIGHT, 0);
			gpioWrite(YLIGHT, 1);
			t1 = gpioTick();
			while(1)
			{	int* handle = pca9685setup(ADDRESS, 50);
				if (handle < 0)
					printf("Error: i2cOpen\n");
				time_sleep(0.005);
				getpulse_width(STRinfo);
				getpulse_width(THRinfo);
				pca9685PWMReset(handle);
				THRinfo->pw = THRcalibration(THRinfo->pw, 5);
				STRinfo->pw = STRcalibration(STRinfo->pw);
				PWMWrite(handle, 0, calcTicks(STRinfo->pw/1000.0, HERTZ));
				PWMWrite(handle, 1, calcTicks(THRinfo->pw/1000.0, HERTZ));
				sleep(0.005);
				i2cClose(handle);

				t2 = gpioTick();
				if ((t2-t1) > ( 7 * CLOCKS_PER_SEC)) break ;
			}
			gpioWrite(YLIGHT, 0);
			checkthread = 0;
			int* handle = pca9685setup(ADDRESS, 50);
			if (handle < 0)
				printf("Error: i2cOpen\n");
			time_sleep(0.005);
		}


		PWMWrite(handle, 0, calcTicks(STRinfo->pw/1000.0, HERTZ));
		PWMWrite(handle, 1, calcTicks(THRinfo->pw/1000.0, HERTZ));
		//printf("THR=%d \t\t STR=%d \n", THRinfo->pw, STRinfo->pw);

		i2cClose(handle);
		sleep(0.005);
	}
	//종료
	gpioStopThread(p1); time_sleep(0.3);
	gpioTerminate();
	free(STRinfo); free(THRinfo);
	return 0 ;
}

int calcTicks(float impulseMs, int hertz)
{
	float cycleMs = 1000.0f / hertz;
	return (int)(MAX_PWM * impulseMs / cycleMs + 0.5f);
}

int THRcalibration(int pw, float step)
{
	int result = (weighting * pw) + ((1-weighting) * saveTHRpw);
	if(pw > 2000) 				result = 2000;
	if(pw < 1000) 				result = 1000;
	if(pw < 1550 && pw > 1450)	result = 1500;
	saveTHRpw = result;
	result = (pw-1500)/step + 1500;
	printf("thrpulse = %d\n\n", result);
	return result;
}


int STRcalibration(int pw)
{
	int result = (weighting * pw) + ((1-weighting) * saveSTRpw);
	if(pw > 2000) 				result = 2000;
	if(pw < 1000) 				result = 1000;
	if(pw < 1550 && pw > 1450)	result = 1500;
	saveSTRpw = result;
	//printf("strpulse = %d\n\n", result);
	return result;
}


